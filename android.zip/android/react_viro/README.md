This directory is where the bridge build artifacts are copied to when running prepareRelease.sh script.

This directory needs to be vended alongside gvr_common and viro_renderer in order for our developers to build their application against all 3 of them.

